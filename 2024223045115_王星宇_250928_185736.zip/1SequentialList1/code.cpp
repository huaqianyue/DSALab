#include <iostream>  // 用于输入输出 (cout, cerr, endl)
#include <cstring>   // 用于 memset
#include <cstdlib>   // 用于 exit

using namespace std; // 使用 std 命名空间，方便直接使用 cout, cerr, endl, exit

#define MaxSize 50
typedef int ElemType;
typedef int Status;

// 顺序表结构定义
typedef struct {
    ElemType data[MaxSize]; // 顺序表元素
    int length;             // 顺序表当前长度
} SqList;

// 初始化顺序表函数，构造一个空的顺序表
Status InitList(SqList &L) {
    // memset(L.data, 0, sizeof(L.data)); // 这一行在C++中通常不是必需的，因为length=0表示空表
                                       // 如果需要确保所有未使用的内存清零，可以保留，但会增加开销
    L.length = 0;                      // 初始化长度为0
    return 0;
}

// 打印顺序表
void PrintList(SqList L) {
    cout << "[";
    for (int i = 0; i < L.length; i++) {
        cout << L.data[i];
        if (i < L.length - 1) cout << ", ";
    }
    cout << "]";
}

// 实现这个函数：
// 从顺序表中删除具有最小值的元素并由函数返回被删元素的值。
// 空出的位置由最后一个元素填补，若顺序表为空则显示出错信息并退出。
int deleteMin(SqList &L) {
    // 1. 如果顺序表为空，应打印错误信息到 cerr 并调用 exit(1)
    if (L.length == 0) {
        cerr << "错误：顺序表为空，无法删除最小值元素。" << endl;
        exit(1); // 退出程序，返回状态码1表示错误
    }

    // 2. 查找最小值及其索引
    int minVal = L.data[0];    // 假设第一个元素是最小值
    int minIndex = 0;          // 记录最小值元素的索引

    for (int i = 1; i < L.length; ++i) {
        if (L.data[i] < minVal) {
            minVal = L.data[i];
            minIndex = i;
        }
    }

    // 3. 用最后一个元素填补空位
    // 即使最小值元素就是最后一个元素，此操作也无害（它会用自身覆盖自身）
    L.data[minIndex] = L.data[L.length - 1];

    // 4. 顺序表长度减1
    L.length--;

    // 5. 返回被删除的最小值
    return minVal;
}

// 简单的测试主函数，方便你调试
int main() {
    SqList L1, L2, L3; // 增加一个 L3 用于测试空表情况
    InitList(L1);
    InitList(L2);
    InitList(L3);
    
    // 测试用例1：正常删除最小值
    cout << "=== 测试用例1：正常删除最小值 ===" << endl;
    L1.data[0] = 3; L1.data[1] = 1; L1.data[2] = 4; L1.data[3] = 2; L1.data[4] = 5;
    L1.length = 5;
    
    cout << "原始顺序表: ";
    PrintList(L1);
    cout << "，长度: " << L1.length << endl;
    
    int min_val1 = deleteMin(L1);
    cout << "删除的最小值: " << min_val1 << endl;
    cout << "结果顺序表: ";
    PrintList(L1);
    cout << "，长度: " << L1.length << endl << endl;
    
    // 测试用例2：单元素顺序表
    cout << "=== 测试用例2：单元素顺序表 ===" << endl;
    L2.data[0] = 7;
    L2.length = 1;
    
    cout << "原始顺序表: ";
    PrintList(L2);
    cout << "，长度: " << L2.length << endl;
    
    int min_val2 = deleteMin(L2);
    cout << "删除的最小值: " << min_val2 << endl;
    cout << "结果顺序表: ";
    PrintList(L2);
    cout << "，长度: " << L2.length << endl << endl;

    // 测试用例3：空顺序表 (预期将导致程序退出)
    cout << "=== 测试用例3：空顺序表 ===" << endl;
    cout << "此测试将尝试从一个空顺序表中删除元素，根据要求，这应该导致程序终止。" << endl;
    cout << "如果程序终止，则表示错误处理功能正常。" << endl;
    
    cout << "原始顺序表: ";
    PrintList(L3);
    cout << "，长度: " << L3.length << endl;
    
    cout << "尝试从空顺序表 L3 中删除最小值..." << endl;
    deleteMin(L3); // 预期此调用将导致程序退出

    // 如果程序没有按预期退出，下面的这行代码将被打印出来
    cout << "如果程序正常退出，这行代码将不会被打印。" << endl;
    
    return 0; // 如果程序没有退出，将返回0（表示成功，但这不符合预期）
}