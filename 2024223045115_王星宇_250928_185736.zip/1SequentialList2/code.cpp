#include <iostream>  // 用于输入输出 (cout, cerr, endl)
#include <cstring>   // 用于 memset
#include <cstdlib>   // 用于 exit

using namespace std; // 使用 std 命名空间，方便直接使用 cout, cerr, endl, exit

#define MaxSize 50
typedef int ElemType;
typedef int Status; // 0 表示成功，非 0 表示失败（尽管这里失败会直接退出）

// 顺序表结构定义
typedef struct {
    ElemType data[MaxSize]; // 顺序表元素
    int length;             // 顺序表当前长度
} SqList;

// 初始化顺序表函数，构造一个空的顺序表
Status InitList(SqList &L) {
    memset(L.data, 0, sizeof(L.data)); // 初始化数据为0 (可选，但根据原代码保留)
    L.length = 0;                      // 初始化长度为0
    return 0; // 0 表示成功
}

// 打印顺序表
void PrintList(SqList L) {
    cout << "[";
    for (int i = 0; i < L.length; i++) {
        cout << L.data[i];
        if (i < L.length - 1) cout << ", ";
    }
    cout << "]";
}

// 实现这个函数：
// 在第i个位置插入元素e（注意：i从1开始计数）
// 如果i不在合理范围[1, L.length+1]内，应打印错误信息到 cerr 并调用 exit(1)
// 如果顺序表已满，也应显示错误信息并退出
Status ListInsert(SqList &L, int i, ElemType e) {
    // 1. 检查顺序表是否已满
    if (L.length >= MaxSize) {
        cerr << "错误：顺序表已满，无法插入元素 " << e << "。" << endl;
        exit(1); // 退出程序
    }

    // 2. 检查插入位置 i 是否合法
    // 合法范围是 [1, L.length + 1]
    if (i < 1 || i > L.length + 1) {
        cerr << "错误：插入位置 i (" << i << ") 不合法。合法范围为 [1, " << L.length + 1 << "]。" << endl;
        exit(1); // 退出程序
    }

    // 3. 将从第 i 个位置开始（包括第 i 个）的所有元素向后移动一位
    // 注意：i 是从 1 开始的，对应数组索引是 i-1
    // 循环从最后一个元素（L.length - 1）开始，一直到插入位置的前一个元素（i - 1）
    for (int k = L.length; k >= i; --k) {
        L.data[k] = L.data[k - 1];
    }

    // 4. 在第 i 个位置（数组索引 i-1）插入新元素 e
    L.data[i - 1] = e;

    // 5. 顺序表长度加 1
    L.length++;

    return 0; // 插入成功，返回 0
}

// 简单的测试主函数，方便你调试
int main() {
    SqList L1, L2, L3, L4, L5;
    InitList(L1);
    InitList(L2);
    InitList(L3);
    InitList(L4); // 用于测试满表
    InitList(L5); // 用于测试非法位置

    // 测试用例1：中间插入
    cout << "=== 测试用例1：中间插入 ===" << endl;
    L1.data[0] = 1; L1.data[1] = 3; L1.data[2] = 5;
    L1.length = 3;
    
    cout << "原始顺序表: ";
    PrintList(L1);
    cout << "，长度: " << L1.length << endl;
    cout << "插入元素2到位置2（第2个位置）" << endl;
    
    ListInsert(L1, 2, 2);
    cout << "插入后顺序表: ";
    PrintList(L1);
    cout << "，长度: " << L1.length << endl << endl; // 预期: [1, 2, 3, 5], 长度: 4
    
    // 测试用例2：末尾插入
    cout << "=== 测试用例2：末尾插入 ===" << endl;
    L2.data[0] = 1; L2.data[1] = 2;
    L2.length = 2;
    
    cout << "原始顺序表: ";
    PrintList(L2);
    cout << "，长度: " << L2.length << endl;
    cout << "插入元素3到位置3（末尾位置）" << endl;
    
    ListInsert(L2, 3, 3);
    cout << "插入后顺序表: ";
    PrintList(L2);
    cout << "，长度: " << L2.length << endl << endl; // 预期: [1, 2, 3], 长度: 3

    // 测试用例3：头部插入 (插入到位置1)
    cout << "=== 测试用例3：头部插入 ===" << endl;
    L3.data[0] = 10; L3.data[1] = 20;
    L3.length = 2;
    cout << "原始顺序表: ";
    PrintList(L3);
    cout << "，长度: " << L3.length << endl;
    cout << "插入元素5到位置1（头部位置）" << endl;
    ListInsert(L3, 1, 5);
    cout << "插入后顺序表: ";
    PrintList(L3);
    cout << "，长度: " << L3.length << endl << endl; // 预期: [5, 10, 20], 长度: 3

    // 测试用例4：顺序表已满 (预期将导致程序退出)
    cout << "=== 测试用例4：顺序表已满 ===" << endl;
    cout << "此测试将尝试向一个已满的顺序表插入元素，根据要求，这应该导致程序终止。" << endl;
    cout << "如果程序终止，则表示错误处理功能正常。" << endl;
    for (int i = 0; i < MaxSize; ++i) { // 填满顺序表
        L4.data[i] = i + 1;
    }
    L4.length = MaxSize;
    cout << "原始顺序表 (已满): ";
    PrintList(L4);
    cout << "，长度: " << L4.length << endl;
    cout << "尝试插入元素 99 到位置 1..." << endl;
    ListInsert(L4, 1, 99); // 预期此调用将导致程序退出

    // 测试用例5：插入位置不合法 (预期将导致程序退出)
    cout << "=== 测试用例5：插入位置不合法 ===" << endl;
    cout << "此测试将尝试向一个顺序表插入到非法位置，根据要求，这应该导致程序终止。" << endl;
    cout << "如果程序终止，则表示错误处理功能正常。" << endl;
    L5.data[0] = 100;
    L5.length = 1;
    cout << "原始顺序表: ";
    PrintList(L5);
    cout << "，长度: " << L5.length << endl;
    cout << "尝试插入元素 200 到位置 0 (非法位置)..." << endl;
    ListInsert(L5, 0, 200); // 预期此调用将导致程序退出 (i < 1)

    // 如果程序没有按预期退出，下面的这行代码将被打印出来
    cout << "如果程序正常退出，这行代码将不会被打印。" << endl;
    
    return 0; // 如果程序没有退出，将返回0（表示成功，但这不符合预期）
}